﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2
{
    public class clsPortal
    {
        Random sluOtc = new Random();
        public string GetStudNumber(int year, int group, string fio)
        {
            string[] FIO = fio.Split(' ');        
            return $"{year}.{group}.{FIO[0][0]}{FIO[1][0]}{FIO[2][0]}";
        }
        public double MinAVG(string[] marks)
        {
            double sum = 0;
            foreach(string m in marks)
            {
                sum += int.Parse(m);
            }
            return sum / marks.Length;
        }
        public List<Mark> GetMarks(DateTime now, List<Student> students)
        {
            
            List<Mark> ListMarks = new List<Mark>();
            string[] marks = { "2", "3", "4", "5", "п", "н", "б", " " };
            
            int day;
            foreach (Student student in students)
            {
                day = 0;
                for ( int i = 0; i< 10; i++)
                {
                    Mark mark = new Mark(now.AddDays(day), marks[sluOtc.Next(8)], student);
                    day++;
                    ListMarks.Add(mark);

                }

            }
            return ListMarks;
        }
        public int[] GetCountDisease(List<Mark> marks)
        {
            Dictionary<int, int> res = new Dictionary<int, int>();
            var ttt = (from m in marks
                       group m by m.date.Month into g
                       select new { date = g.Key }).ToList();
            foreach (var t in ttt)
            {
                int prom = marks.FindAll(m => m.date.Month == t.date && m.estimation == "н").Count;
                res.Add(t.date, prom);
            }
            return res.Select(x => x.Value).ToArray();
        }
       public  int[] GetCountTruancy(List<Mark> marks)
        {
            Dictionary<int, int> res = new Dictionary<int, int>();
            var ttt = (from m in marks
                       group m by m.date.Month into g
                       select new { date = g.Key }).ToList();
            foreach (var t in ttt)
            {
                int prom = marks.FindAll(m => m.date.Month == t.date && m.estimation == "б").Count;
                res.Add(t.date, prom);
            }
            return res.Select(x => x.Value).ToArray();
        }
    }
    public class Student
    {
        public int year { get; set; }
        public int group { get; set; }
        public string fio { get; set; }
        public Student (int a,int b, string Fio)
        {
            year = a;
            group = b;
            fio = Fio;
        }

    }
    public class Mark
    {
        public DateTime date { get; set; }
        public string estimation { get; set; }
        public Student student { get; set; }
        public Mark(DateTime d, string estm, Student st)
        {
            date = d;
            estimation = estm;
            student = st;
        }
    }
}
